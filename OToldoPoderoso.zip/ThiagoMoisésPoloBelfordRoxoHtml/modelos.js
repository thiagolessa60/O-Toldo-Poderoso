
		var tablista = [
            ["vazio", 320],
                ["Comprida","CoberturaComprida100",200],
                    ["Cobertura Abaulada","CoberturaPoliprop100", 160],
                        ["Cobertura Triangular","CoberturaTriangular100", 90],
                            ["Toldo Fixo","ToldoFixo100", 220],
                                ["Toldo Retratil","ToldoRetratil100", 79],
                                    ["Toldo Retratil Triangular","ToldoRetratilTriangular100", 190] ];
    
                function Abrirlista(ind) {
                    var foto = document.getElementById("imgDes");
                        var prec = document.getElementById("proDes");
                            var titd = document.getElementById("titDes");
            
                                titd.innerHTML = tablista[ind][0];
                                    foto.src = "Imagens/" + tablista[ind][1] + ".png";
                                        prec.innerHTML = "<br/>Preço: R$ " + 
                                            tablista[ind][2] + ",00";
            }
    