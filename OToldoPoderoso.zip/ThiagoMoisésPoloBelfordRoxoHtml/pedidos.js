var tabPrcProd = [ 90, 85, 65, 60, 100, 130,130];
		
		function IncluiLista( sel ) {
		    var prod = sel.selectedIndex;
		        if ( prod != 0 ) {
		        var prc = tabPrcProd[prod];
		            sel.selectedIndex = 0;
		                with ( sel.form ) {
		                    listadePedidos.value += sel.options[prod].text + '\n';
		                        TxtTotal.value = prc + parseInt(TxtTotal.value);
		}
		}
		                            else
		                                alert("Nenhum Produto selecionado!");
		}