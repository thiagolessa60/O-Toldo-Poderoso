var Itensdesk = new Array(6);
	Itensdesk[0] = [ "Lona","Uso: Coberturas",,"Lona100",, 85];

	Itensdesk[1] = [ "Polipropileno","Uso: Coberturas",,"Polipropileno",,120];

	Itensdesk[2] = [ "Policarbonato","Uso: Coberturas",,"Policarbonato100",, 130];

	Itensdesk[3] = [ "Tecido Sintetico","Uso: Toldo",,"Sintetico100",, 110];

	Itensdesk[4] = [ "Tecido Acrilicio","Uso: Toldo",,"Acrilico100",, 75];

	Itensdesk[5] = [ "Poliester","Uso: Toldo",,"Poliester100",, 200];

		function Abrirproduto(tipo) {
			var jan = open("", Itensdesk[tipo][0],
				"location=no,status=no," +
					"width=350,height=460");

	with (jan.document) {
		write("<!DOCTYPE html>");
			write("<html><head><title>O Toldo Poderoso</title>");
				write("<link rel='stylesheet' type='text/css'");
					write(" href='stylesheet.css'>");
						write("</head><body><section>");
							write("<div class='janInfo'>");
								write("<h2>", Itensdesk[tipo][0], "</h2>");
									write("<p><img class='janInfoImg' src='Imagens/",
										Itensdesk[tipo][3], ".jpg' /></p>");
											write("<div class='janInfoDetalhe'>");
												write("<p>", Itensdesk[tipo][1], "</p>" );
													write("<p> Preço por m² :R$ ",
														Itensdesk[tipo][5], ",00</p>" );
														write("<div class='janInfo'>");
															write("<input type='button' value='Fechar' ");
																write("onClick='window.close();'/>");
																	write("</form></div></section>");
																		write("</body></html>");
                                                                        close();
}
}                                                                   